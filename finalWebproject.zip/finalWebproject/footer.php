
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        footer{clear: both; 
    background-color: #304b4d;
     text-align: center; 
     color: #fff;
      font-size: medium; 
      font-family: 'Courier New', Courier, monospace; 
      height: 145px;
        }
    </style>
    </head>
    
    <body>
   
<footer id="foot" >    <div class="icon">
    <i class ="fa fa-phone" style="float: left; padding-left: 40px; "> 92000675 </i> </p>  
    <br>
    <div class="icon">
        <i class ="fa fa-envelope" style="float: left;  padding-left: 40px; "> <a href="mailto:PetCare@Clinic.com" style="text-decoration: none; color: #fff; ">PetCare@Clinic.com</a>  </i>
    <div class="icon"> <i class ="fa fa-twitter" style="float: right; padding-right: 40px; "><a href="#" style="text-decoration: none; color: #fff; "></a>@pet_clinic</i></div>
    <br>
    <div class="icon"> <i class ="fa fa-facebook" style="float: right; padding-right: 40px; "><a href="#" style="text-decoration: none; color: #fff; "></a>@pet_clinic</i></div>
</div> 

<p>All rights reserved for &copy; 2022 PET CARE copany</p></footer>



    </body>

</html>